package com.example.eventcloudapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Replace 'activity_main' with your actual layout file name if different.
        setContentView(R.layout.activity_event_grid);

    }
}
