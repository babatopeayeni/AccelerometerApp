package com.example.eventcloudapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class SmsActivity extends AppCompatActivity {

    // Constant for the SMS permission request code
    private static final int SMS_PERMISSION_REQUEST_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        // Set up the button click listener to request SMS permission
        Button btnRequestSmsPermission = findViewById(R.id.btnRequestSmsPermission);
        btnRequestSmsPermission.setOnClickListener(v -> {
            requestSmsPermission();
        });

        // Optionally, check and update status on activity start:
        requestSmsPermission();
    }

    // Method to request SMS permission
    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            // Request permission if it hasn't been granted yet
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_REQUEST_CODE);
        } else {
            // Permission already granted
            updateSmsStatus(true);
        }
    }

    // Callback method for the permission request result
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                updateSmsStatus(true);
            } else {
                updateSmsStatus(false);
            }
        }
    }

    // Updates the SMS permission status on the UI
    private void updateSmsStatus(boolean granted) {
        TextView tvSmsStatus = findViewById(R.id.tvSmsStatus);
        if (granted) {
            tvSmsStatus.setText("SMS Permission status: Granted");
        } else {
            tvSmsStatus.setText("SMS Permission status: Denied");
        }
    }
}
