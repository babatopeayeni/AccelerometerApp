package com.example.eventcloudapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class EventGridActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // For example, if your layout is activity_event_grid.xml:
        setContentView(R.layout.activity_event_grid);
    }
}
