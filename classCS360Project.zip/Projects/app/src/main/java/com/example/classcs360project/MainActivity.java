package com.example.classcs360project;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.text.Editable;
import android.text.TextWatcher;

public class MainActivity extends AppCompatActivity {

    // Declare references for your UI elements
    private EditText nameText;
    private TextView textGreeting;
    private Button buttonSayHello;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Make sure this matches the layout file name
        setContentView(R.layout.activity_main);

        // Link Java references to the XML elements
        nameText = findViewById(R.id.nameText);
        textGreeting = findViewById(R.id.textGreeting);
        buttonSayHello = findViewById(R.id.buttonSayHello);

        // Initially disable the button
        buttonSayHello.setEnabled(false);

        // Add a TextWatcher to dynamically enable/disable the button
        nameText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // Not used
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Not used
            }

            @Override
            public void afterTextChanged(Editable s) {
                // If the EditText is empty, disable the button; otherwise, enable it
                if (s.toString().trim().isEmpty()) {
                    buttonSayHello.setEnabled(false);
                } else {
                    buttonSayHello.setEnabled(true);
                }
            }
        });
    }

    // Public function called when the user clicks buttonSayHello
    public void SayHello(View view) {
        // Grab the string from nameText
        String name = nameText.getText().toString().trim();

        // If the content is empty (or null), just return
        if (name.isEmpty()) {
            return;
        }

        // Otherwise, set the greeting message
        textGreeting.setText("Hello " + name);
    }
}