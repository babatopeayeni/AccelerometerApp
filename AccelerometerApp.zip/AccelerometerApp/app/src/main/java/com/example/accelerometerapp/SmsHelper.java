package com.example.accelerometerapp;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsHelper {
    public static final int SMS_PERMISSION_CODE = 101;

    public static boolean checkSmsPermission(Activity activity) {
        if (ContextCompat.checkSelfPermission(activity, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(activity, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
            return false;
        }
        return true;
    }

    public static void sendSms(Activity activity, String phoneNumber, String message) {
        if (checkSmsPermission(activity)) {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phoneNumber, null, message, null, null);
                Toast.makeText(activity, "SMS sent.", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(activity, "SMS failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
    }
}
