package com.example.accelerometerapp;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class DataActivity extends AppCompatActivity {
    private DataDatabaseHelper dbHelper;
    private EditText editData;
    private Button btnAdd, btnUpdate, btnDelete;
    private GridView dataGrid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);

        dbHelper = new DataDatabaseHelper(this);

        editData = findViewById(R.id.editData);
        btnAdd = findViewById(R.id.btnAdd);
        btnUpdate = findViewById(R.id.btnUpdate);
        btnDelete = findViewById(R.id.btnDelete);
        dataGrid = findViewById(R.id.dataGrid);

        refreshGrid();

        btnAdd.setOnClickListener(v -> {
            String data = editData.getText().toString();
            if (dbHelper.insertData(data)) {
                Toast.makeText(this, "Added", Toast.LENGTH_SHORT).show();
                refreshGrid();
            } else {
                Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
            }
        });

        btnUpdate.setOnClickListener(v -> {
            String data = editData.getText().toString();
            if (dbHelper.updateData(1, data)) {
                Toast.makeText(this, "Updated", Toast.LENGTH_SHORT).show();
                refreshGrid();
            } else {
                Toast.makeText(this, "Update failed", Toast.LENGTH_SHORT).show();
            }
        });

        btnDelete.setOnClickListener(v -> {
            if (dbHelper.deleteData(1)) {
                Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show();
                refreshGrid();
            } else {
                Toast.makeText(this, "Delete failed", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void refreshGrid() {
        Cursor cursor = dbHelper.getAllData();
        String[] from = {"_id", "data"};
        int[] to = {android.R.id.text1, android.R.id.text2};
        SimpleCursorAdapter adapter = new SimpleCursorAdapter(this,
                android.R.layout.simple_list_item_2, cursor, from, to, 0);
        dataGrid.setAdapter(adapter);
    }
}
